import {connect} from 'react-redux';
import LaunchesView from './Launches';
import { fetchLaunches } from "../actions/Launches";
import ConnectedView from "./ConnectedView";

const mapStateToProps = (state) => ({
    launchCollection: state.launchCollection
});

const mapDispatchToProps = dispatch => ({
    fetchLaunches: () => dispatch(fetchLaunches())
});

const launchesView = connect(mapStateToProps, mapDispatchToProps)(LaunchesView);

export default ConnectedView(launchesView, "launches");