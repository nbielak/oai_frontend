import {connect} from 'react-redux';
import {fetchLaunch} from '../actions/Launches';
import LaunchShow from './launch_show';
import ConnectedView from "./ConnectedView";


const mapStateToProps = (state, ownProps) => ({
    launchCollection: state.launchCollection
})

const mapDispatchToProps = dispatch => ({
    fetchLaunch: flightNumber => dispatch(fetchLaunch(flightNumber))
})

const launchShow = connect(mapStateToProps, mapDispatchToProps)(LaunchShow);

export default ConnectedView(launchShow, 'launch')