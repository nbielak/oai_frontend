import React, { Component } from 'react';
import Launch from '../components/Launch';

class LaunchesView extends Component {
  constructor(props) {
    super(props)
  }

  componentDidMount() {
    this.props.fetchLaunches();
  }

  getContent() {
    const { launchCollection } = this.props;

    if (!launchCollection || launchCollection.fetching) {
      return <div> LOADING </div>;
    }

    if (!launchCollection.launches.length) {
      return <div> NO DATA </div>;
    }
    let launches = launchCollection.launches.map(launch => {
      return (<Launch key={launch.flightNumber} launch={launch}/>)
    })

    return <ul className="launch-index">{launches}</ul>;
  }

  render() {
    return (
      <div>
        <h2> SpaceX launches </h2>
        {this.getContent()}
      </div>
    );
  }
}

export default LaunchesView;
