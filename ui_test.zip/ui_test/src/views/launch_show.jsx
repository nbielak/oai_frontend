import React, {Component} from 'react';
import RocketInfo from '../components/rocket_info';
import ImageCarousel from "../components/carousel";

class LaunchShow extends Component {
    constructor(props) {
        super(props)
    }

    componentDidMount() {
        this.props.fetchLaunch(this.props.match.params.flightNumber)
    }

    render() {
        if (!this.props.launchCollection.launches.length || 
            this.props.launchCollection.fetching) {
            return (<div> Loading... </div>)
        }

        let launch = this.props.launchCollection.launches[0];
        let imageUrls = launch.links.flickr_images;
        let images = (imageUrls.length ? <ImageCarousel imageUrls={imageUrls} /> : <h3>No Images</h3>);
        return (
          <div className="launch-show">
            <h1>{launch.mission_name}</h1>
            <div className="launch-rocket">
              <div className="info-display">
                <h2>Launch Information</h2>
                <div className="info">Flight Number: {launch.flight_number}</div>
              </div>

              <div className="info-display">
                <RocketInfo launch={launch} />
              </div>
            </div>

            <div className="images">
              <h2>Images</h2>
              <div className="carousel">
                  {images}
              </div>
            </div>
          </div>
        );
    }
}

export default LaunchShow;