import {combineReducers} from 'redux';
import launchCollection from './LaunchCollectionReducer';

const rootReducer = combineReducers({
  launchCollection
});

export default rootReducer;
