import { ACTIONS } from '../actions/Launches';

const initialState = {
  launches: [],
  fetching: false
};

const actionHandlers = {
  [ACTIONS.REQUEST_LAUNCHES]: ({ state }) => ({
    ...state,
    fetching: true
  }),
  [ACTIONS.RECEIVE_LAUNCHES]: ({ state, action }) => ({
    ...state,
    fetching: false,
    launches: [...action.payload.launches]
  }),
  [ACTIONS.RECEIVE_LAUNCH]: ({state, action}) => ({
    ...state,
    fetching: false,
    launches: [action.payload.launch]
  })
};

export default (state = initialState, action) =>
  actionHandlers[action.type] ? actionHandlers[action.type]({ state, action }) : state;
