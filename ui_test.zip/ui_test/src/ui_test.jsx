import React from "react";
import ReactDOM from "react-dom";
import Routes from  './components/routes';
import configureStore from './stores/store';
import App from './components/index';

import "styles/base/_main.sass"  // Global styles
import "styles/base/_common.sass"  // Global styles
import "styles/_style.sass"  // Css-module styles

document.addEventListener("DOMContentLoaded", () => {
    let store = configureStore();
    const app = document.getElementById('app');
    ReactDOM.render(<App store={store}/>, app)
})

// Webpack Hot Module Replacement API
if (module.hot) {
    module.hot.accept('./components/routes', () => {
        renderApp(require('./components/routes').default);
    })
}