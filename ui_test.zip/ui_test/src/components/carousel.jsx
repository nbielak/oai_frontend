import React from 'react';
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Carousel } from "react-responsive-carousel";

const ImageCarousel = ({imageUrls}) => {
    
    const images = imageUrls.map((url, index) => {
        return (
            <div className="carousel-item">
                <img className="carousel-image" src={url}/>
                <p className="legend">Image {index + 1}</p>
            </div>
        )
    })
    return (
        <Carousel 
            
            dynamicHeight={false}
            autoPlay={true}
            swipeable={true}
            showThumbs={false}>
            {images}
        </Carousel>

    )
}

export default ImageCarousel;