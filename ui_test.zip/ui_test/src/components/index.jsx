import React from 'react'
import {AppContainer} from 'react-hot-loader'
import Routes from './routes'

import { Provider } from "react-redux";

const App = ({store}) => (
  <Provider store={store}>
    <AppContainer>
      <Routes/>
    </AppContainer>
  </Provider>
);

export default App;




