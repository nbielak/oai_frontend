import React, {Component}from 'react';
import {withRouter} from 'react-router-dom';

class Launch extends Component {
  constructor(props) {
    super(props);
    this.handleClick = this.handleClick.bind(this)
  }

  handleClick(){
    this.props.history.push(`/launches/${this.props.launch.flight_number}`)
  }
  
  render() {
    let launch = this.props.launch;
    return (
      <li className="launch-index-item" onClick={this.handleClick}>
        <h2> Mission Name: {launch.mission_name} </h2>
        <div className="index-item-info">
          <div> Mission ID: {launch["mission_id"][0] || "NONE"} </div>
          <div> Rocket Name: {launch.rocket.rocket_name} </div>
        </div>
      </li>
    );
  }
  
}

export default withRouter(Launch);