import React from 'react';
import {
  BrowserRouter as Router,
  Switch,
  Route
} from 'react-router-dom';
import LaunchesContainer from "../views/launches_container";
import LaunchShowContainer from '../views/launch_show_container';

const Routes = () => (
  <Router>
    <div>
      <Switch>
        <Route exact path="/" component={LaunchesContainer} />
        <Route path="/launches/:flightNumber" component={LaunchShowContainer} />
      </Switch>
    </div>
  </Router>
);

export default Routes;
