import React from 'react';

const RocketInfo = ({launch}) => {
    let rocket = launch.rocket;
    
    return (
        <div>
            <h2>Rocket Information</h2>
            <div>
                <div className="info">
                    Rocket Name: {rocket.rocket_name}
                </div>
                
                <div className="info">
                    Rocket Type: {rocket.rocket_type}
                </div>

            </div>
        </div>
    )
}

export default RocketInfo;