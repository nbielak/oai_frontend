import LaunchService from '../services/LaunchService';

export const ACTIONS = {
  REQUEST_LAUNCHES: 'REQUEST_LAUNCHES',
  RECEIVE_LAUNCHES: 'RECEIVE_LAUNCHES',
  RECEIVE_LAUNCH: 'RECEIVE_LAUNCH'
};

const requestLaunches = () => ({
  type: ACTIONS.REQUEST_LAUNCHES
});

const receiveLaunches = response => ({
  type: ACTIONS.RECEIVE_LAUNCHES,
  payload: {
    launches: response.data
  }
});

const receiveLaunch = response => ({
  type: ACTIONS.RECEIVE_LAUNCH,
  payload: {
    launch: response.data
  }
})

export const fetchLaunches = () => dispatch => {
  dispatch(requestLaunches());
  return LaunchService.get().then(response => dispatch(receiveLaunches(response)));
};

export const fetchLaunch = flightNumber => dispatch => {
  dispatch(requestLaunches());
  return LaunchService.show(flightNumber).then(response => dispatch(receiveLaunch(response)));
}

